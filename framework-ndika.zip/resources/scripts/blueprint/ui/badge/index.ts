export { default as UiBadge } from './UiBadge';
